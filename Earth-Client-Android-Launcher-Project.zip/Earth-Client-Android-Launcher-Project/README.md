# Earth Client Android project

Android Studio project wrapper for the Earth Client Mobile web UI prototype.

## Build APK
1. Install Android Studio (with Android SDK Platform 35 and JDK 17).
2. Open this folder (`Earth Client-Android-Project`) in Android Studio.
3. Wait for Gradle sync.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

## Included
- Android Activity hosting the local prototype in WebView
- Dark neon UI with PvP preferences, FPS UI controls, pack filename list, JSON export

## Limitations
- This is an Android Studio project, not a precompiled APK.
- It does not launch or modify Minecraft Bedrock, and does not install resource packs into Minecraft.
- FPS controls are preferences only; no actual game FPS boost is guaranteed.
- Unaffiliated fan project; not affiliated with Mojang, Microsoft, or Lunar Client.


## APK'yi GitHub üzerinden otomatik derleme (bilgisayarda Android Studio gerekmez)

1. Bu projeyi ZIP'ten çıkar.
2. GitHub'da yeni, boş bir repository oluştur.
3. Proje dosyalarının tamamını repository'ye yükle ve `main` dalına gönder.
4. Repository içindeki **Actions** sekmesini aç. `Build Earth Client APK` iş akışı otomatik çalışır; istersen **Run workflow** ile de başlatabilirsin.
5. İşlem başarılı olunca ilgili çalıştırmanın altındaki **Artifacts** bölümünden `Earth Client-debug-APK` dosyasını indir. ZIP'in içindeki `app-debug.apk` dosyasını Android telefona aktararak yükleyebilirsin.

Not: Bu ortamda Android SDK/Gradle derleme araçları bulunmadığı için burada gerçek APK derlenemedi. Workflow, GitHub'ın derleme ortamında APK üretmek için eklendi. Bu bir debug APK olacaktır; Android kurulumunda bilinmeyen kaynaklardan yüklemeye izin vermen gerekebilir.

## Gerçek Minecraft başlatma

Ana ekrandaki Minecraft'ı Aç düğmesi cihazda yüklü resmi Minecraft Bedrock uygulamasını (`com.mojang.minecraftpe`) açar. Minecraft kurulu değilse Play Store sayfasını açmayı dener. Bu ayrı bir Minecraft istemcisi değildir; oyun dosyalarını değiştirmez ve FPS artışı garanti etmez. Bu ZIP kaynak projedir, APK değildir.
