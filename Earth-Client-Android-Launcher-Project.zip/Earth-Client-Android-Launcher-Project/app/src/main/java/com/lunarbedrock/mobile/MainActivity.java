package com.lunarbedrock.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String MC_PACKAGE = "com.mojang.minecraftpe";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,13,23));
        getWindow().setNavigationBarColor(Color.rgb(8,13,23));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8,13,23));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new LauncherBridge(), "LunarLauncher");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class LauncherBridge {
        @JavascriptInterface public boolean isMinecraftInstalled() {
            try { getPackageManager().getPackageInfo(MC_PACKAGE, 0); return true; }
            catch (PackageManager.NameNotFoundException e) { return false; }
        }
        @JavascriptInterface public void launchMinecraft() {
            runOnUiThread(() -> {
                Intent launch = getPackageManager().getLaunchIntentForPackage(MC_PACKAGE);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                } else {
                    Toast.makeText(MainActivity.this, "Minecraft Bedrock bulunamadı. Önce Minecraft'ı kur.", Toast.LENGTH_LONG).show();
                    try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com/store/apps/details?id=" + MC_PACKAGE))); }
                    catch (Exception ignored) {}
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
